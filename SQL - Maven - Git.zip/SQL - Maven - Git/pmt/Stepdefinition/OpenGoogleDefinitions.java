package Stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OpenGoogleDefinitions {
	WebDriver driver;
	
	@Given("^user  entering google\\.co\\.in$")
	public void user_entering_google_co_in() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\1576486\\Documents\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.google.com/?gws_rd=ssl&hl=en");
	}

	@When("^user is typing the search term \"([^\"]*)\"$")
	public void user_is_typing_the_search_term(String searchTerm) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		//Fetching the data from featurefiles
		driver.findElement(By.name("q")).sendKeys(searchTerm);

	}

	@When("^enters the retunr key$")
	public void enters_the_retunr_key() throws Throwable {
		// Write code here that turns the phrase above into concrete actions

		driver.findElement(By.name("q")).sendKeys(Keys.RETURN);

	}

	@Then("^the user should see the search result$")
	public void the_user_should_see_the_search_result() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		boolean status =driver.findElement(By.partialLinkText("Nazeer")).isDisplayed();
		if(status) {
			System.out.println("Results is displayed");
		}
	
	
//	@Given("^user  entering google\\.co\\.in$")
//	public void user_entering_google_co_in() throws Throwable {
//		System.out.println("User is on Google home");
//	   
//	}
//
//	@When("^user is typing the search term \"([^\"]*)\"$")
//	public void user_is_typing_the_search_term(String arg1) throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("User is on search");
//	}
//
//	@When("^enters the retunr key$")
//	public void enters_the_retunr_key() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("User is on return key");
//	}
//
//	@Then("^the user should see the search result$")
//	public void the_user_should_see_the_search_result() throws Throwable {
//	    // Write code here that turns the phrase above into concrete actions
//		System.out.println("User is on search result");
//	   
//	}

	


}
	
}








